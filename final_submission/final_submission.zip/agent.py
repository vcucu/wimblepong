"""
This is a submission for the final project of Reinforncement learning
by Aletta Tordai 915247 and Veronika Cucorová 876344
"""


from wimblepong import Wimblepong
import random
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
import cv2
import numpy as np
import scipy.misc
import matplotlib.pyplot as plt
from collections import namedtuple

Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward', 'done'))


class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def push(self, *args):
        """Saves a transition."""
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


class PongDQN(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.n_actions = 3
        self.state_space_dim = (80, 80)
        self.linear_input_dim = self.linear_input(self.state_space_dim)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.conv1 = torch.nn.Conv2d(3, 16, 8, 2)
        self.conv2 = torch.nn.Conv2d(16, 32, 3, 2)
        self.fc1 = torch.nn.Linear(self.linear_input_dim, 200)
        self.fc2 = torch.nn.Linear(200, self.n_actions)
        self.initialize()

    def initialize(self):
        torch.nn.init.xavier_uniform_(self.conv1.weight)
        torch.nn.init.xavier_uniform_(self.conv2.weight)
        torch.nn.init.xavier_uniform_(self.fc1.weight)
        torch.nn.init.xavier_uniform_(self.fc2.weight)

    def linear_input(self, state_space_dim):
        a = self.conv2d_dims(80, 8, 2)
        a = self.conv2d_dims(a, 3, 2)
        b = self.conv2d_dims(80, 8, 2)
        b = self.conv2d_dims(b, 3, 2)
        return a * b * 32

    def conv2d_dims(self, input, kernel_size, stride):
        return (input - (kernel_size - 1) - 1) // stride + 1

    def forward(self, x):
        x = x.to(self.device)
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = x.reshape(-1, self.linear_input_dim)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class Agent(object):
    def __init__(self):

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.n_actions = 3

        self.policy_net = PongDQN().to(self.device)
        self.target_net = PongDQN().to(self.device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.prev1 = np.zeros((80, 80, 1))
        self.prev2 = np.zeros((80, 80, 1))

        self.name = "AVe"  # A-letta & Ve-ronika hehe

        self.optimizer = torch.optim.Adam(self.policy_net.parameters(), lr=1e-4)
        self.gamma = 0.99
        self.batch_size = 128
        self.replay_buffer_size = 70000

        self.memory = ReplayMemory(self.replay_buffer_size)

    def update_network(self, updates=1):
        for _ in range(updates):
            self._do_network_update()

    # compute the network update sampling from the memory
    def _do_network_update(self):
        if len(self.memory) < self.batch_size:
            return
        transitions = self.memory.sample(self.batch_size)

        batch = Transition(*zip(*transitions))

        non_final_mask = 1 - torch.tensor(batch.done, dtype=torch.uint8)
        non_final_next_states = [s for nonfinal, s in zip(non_final_mask,
                                                          batch.next_state) if nonfinal > 0]
        next_state = torch.stack(batch.next_state).to(self.device)
        non_final_next_states = torch.stack(non_final_next_states).to(self.device)
        state_batch = torch.stack(batch.state).to(self.device)
        action_batch = torch.cat(batch.action).to(self.device)
        reward_batch = torch.cat(batch.reward).to(self.device)

        state_action_values = self.policy_net(state_batch.reshape(-1, 3, 80, 80)).gather(1,
                                                                                         action_batch.to(self.device))

        next_state_values = torch.zeros(self.batch_size).to(self.device)
        next_state_values[non_final_mask.bool()] = self.target_net(non_final_next_states.reshape(-1, 3, 80, 80)).max(1)[
            0].detach()
        expected_state_action_values = reward_batch + (self.gamma * next_state_values)

        loss = F.smooth_l1_loss(state_action_values.squeeze(),
                                expected_state_action_values)
        self.optimizer.zero_grad()
        loss.backward()
        for param in self.policy_net.parameters():
            param.grad.data.clamp_(-1e-1, 1e-1)
        self.optimizer.step()

    def get_action(self, state, epsilon=-1, evaluate=True):
        stacked_state, state = self.preprocess(state, self.prev1, self.prev2)
        self.prev2 = self.prev1
        self.prev1 = state
        sample = random.random()
        if sample > epsilon:
            with torch.no_grad():
                q_values = self.policy_net(stacked_state)
                action = torch.argmax(q_values).item()
                return action
        else:
            action = random.randrange(self.n_actions)
            return action

    def get_name(self):
        return self.name

    def update_target_network(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())

    def reset(self):
        self.prev1 = np.zeros((80, 80, 1))
        self.prev2 = np.zeros((80, 80, 1))

    def store_transition(self, state, action, next_state, reward, done):
        action = torch.Tensor([[action]]).long()
        reward = torch.tensor([reward], dtype=torch.float32)
        stacked_state, prep_state = self.preprocess(np.array(state), self.prev1, self.prev2)
        stacked_state.to(self.device)
        next_state, _ = self.preprocess(np.array(next_state), prep_state, self.prev2)
        next_state.to(self.device)

        # update the previous frames 
        self.prev1 = self.prev2
        self.prev2 = prep_state

        # push the transition to the memory
        self.memory.push(stacked_state, action, next_state, reward, done)

    def preprocess(self, observation, prev_obs_t2, prev_obs_t1):
        observation = np.array(observation)
        observation = cv2.resize(observation, (int(80), int(80))).mean(axis=-1)
        observation[observation < 50] = 0.0
        observation[observation > 50] = 1
        observation = np.expand_dims(observation, axis=-1)
        observation = torch.Tensor(observation)

        stacked = np.concatenate((prev_obs_t1, prev_obs_t2, observation), axis=-1)
        stacked = torch.from_numpy(stacked).float().unsqueeze(0)
        stacked = stacked.transpose(1, 3)

        return stacked, observation

    def load_model(self):
        weights = torch.load("model.mdl", map_location=torch.device(self.device))
        self.policy_net.load_state_dict(weights, strict=False)
        self.target_net.load_state_dict(weights, strict=False)
        self.target_net.eval()
